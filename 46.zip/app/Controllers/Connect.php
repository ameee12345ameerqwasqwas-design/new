<?php

namespace App\Controllers;

use App\Models\KeysModel;
use CodeIgniter\I18n\Time;

class Connect extends BaseController
{
    protected $model, $game, $uKey, $sDev;
    protected $maintenance;   
    protected $staticWords; 

public function __construct() { $db = \Config\Database::connect(); $userDetails1 = $db->table('onoff')->where('id', 1)->get()->getRowArray(); $this->model = new KeysModel(); $this->maintenance = ($userDetails1['status'] == 'on'); $this->staticWords = "Vm8Lk7Uj2JmsjCPVPVjrLa7zgfx3uz9E"; } public function index() { if ($this->request->getPost()) { return $this->index_post(); } else { return view('custom_page'); } }

    public function index_post()
    {
        $isMT = $this->maintenance;
        $game = $this->request->getPost('game');
        $uKey = $this->request->getPost('user_key');
        $sDev = $this->request->getPost('serial');

        $form_rules = [
            'game' => 'required|alpha_dash',
            'user_key' => 'required|min_length[1]|max_length[36]',
            'serial' => 'required|alpha_dash'
        ];

        if (!$this->validate($form_rules)) {
            return $this->response->setJSON([
                'status' => false,
                'reason' => "Bad Parameter",
            ]);
        }

        if ($isMT) {
            $db = \Config\Database::connect();
            $userDetails1 = $db->table('onoff')->where('id', 1)->get()->getRowArray();

            return $this->response->setJSON([
                'status' => true,
                'reason' => $userDetails1['myinput']
            ]);
        }

        if (!$game || !$uKey || !$sDev) {
            return $this->response->setJSON([
                'status' => false,
                'reason' => 'Invalid Parameter'
            ]);
        }

        $time = new Time();
        $model = $this->model;

        $findKey = $model->getKeysGame([
            'user_key' => $uKey,
            'game' => $game
        ]);

        if (!$findKey) {
            return $this->response->setJSON([
                'status' => false,
                'reason' => 'USER OR Games NOT Register'
            ]);
        }

        if ($findKey->status != 1) {
            return $this->response->setJSON([
                'status' => false,
                'reason' => 'User Blocked'
            ]);
        }

        $id_keys = $findKey->id_keys;
        $duration = $findKey->duration;
        $expired = $findKey->expired_date;
        $max_dev = $findKey->max_devices;
        $devices = $findKey->devices ?? ''; 
        $lsDevice = $devices ? explode(",", $devices) : [];
        $cDevices = count($lsDevice);
        $serialOn = in_array($sDev, $lsDevice);
        if (!$serialOn) {
            if ($cDevices < $max_dev) {
                $lsDevice[] = $sDev;
                $setDevice = implode(",", array_unique($lsDevice));
                $model->update($id_keys, ['devices' => $setDevice]);
            } else {
                return $this->response->setJSON([
                    'status' => false,
                    'reason' => 'MAX Devices Reached'
                ]);
            }
        }
        if (!$expired) {
            $setExpired = Time::now()->addHours($duration)->format('Y-m-d H:i:s');
            $model->update($id_keys, ['expired_date' => $setExpired]);
        } else {
            if (!Time::now()->isBefore($expired)) {
                return $this->response->setJSON([
                    'status' => false,
                    'reason' => 'Expired Key Contact With Owner'
                ]);
            }
        }
		
        $db = \Config\Database::connect();
        $mod = $db->table('modname')->where('id', 1)->get()->getRowArray();
        $ftext = $db->table('_ftext')->where('id', 1)->get()->getRowArray();
        $feature = $db->table('Feature')->where('id', 1)->get()->getRowArray();
        $rngcnt = $time->getTimestamp();
        $real = "$game-$uKey-$sDev-$this->staticWords";
        $expiry = $findKey->expired_date 
        ?? Time::now()->addHours($duration)->format('Y-m-d H:i:s');
        return $this->response->setJSON([
            'status' => true,
            'data' => [
                'real' => $real,
                'token' => md5($real),
                'modname' => $mod['modname'] ?? '',
                'mod_status' => $ftext['_status'] ?? '',
                'credit' => $ftext['_ftext'] ?? '',
                'ESP' => $feature['ESP'] ?? 'off',
                'Item' => $feature['Item'] ?? 'off',
                'AIM' => $feature['AIM'] ?? 'off',
                'SilentAim' => $feature['SilentAim'] ?? 'off',
                'BulletTrack' => $feature['BulletTrack'] ?? 'off',
                'Floating' => $feature['Floating'] ?? 'off',
                'Memory' => $feature['Memory'] ?? 'off',
                'Setting' => $feature['Setting'] ?? 'off',
                'expired_date' => (string) $expiry,
                'EXP' => (string) $expiry,
                'exdate' => (string) $expiry,
                'device' => $max_dev,
                'rng' => $rngcnt
            ],
        ]);
    }
}