<?= $this->extend('Layout/Starter') ?>
<?= $this->section('content') ?>

<style>
    body {
        background-image: url('<?= base_url('assets/images/backround1.avif') ?>');
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        background-color: #24193d;
    }
    
    .card {
        background-color: rgba(93, 63, 159, 0.7) !important;
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 15px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        overflow: hidden;
        margin-bottom: 25px;
    }
    
    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 40px rgba(0, 0, 0, 0.4);
    }
    
    .card-header {
        background: linear-gradient(135deg, rgba(93, 63, 159, 0.6), rgba(80, 50, 140, 0.8)) !important;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        color: white !important;
        font-weight: 600;
        padding: 15px 20px;
    }
    
    .card-body {
        padding: 20px;
        color: white;
    }
    
    .table th {
        background-color: rgba(167, 139, 250, 0.2) !important;
        color: white;
    }
    
    .status-active {
        background: #10b981;
        color: white;
        padding: 6px 12px;
        border-radius: 50px;
        font-size: 0.85rem;
    }
    
    .status-inactive {
        background: #ef4444;
        color: white;
        padding: 6px 12px;
        border-radius: 50px;
        font-size: 0.85rem;
    }
    
    .game-badge {
        background: rgba(167, 139, 250, 0.2);
        color: #a78bfa;
        padding: 4px 10px;
        border-radius: 50px;
        font-size: 0.8rem;
        margin-right: 4px;
        margin-bottom: 4px;
        display: inline-block;
    }
    
    .btn-action {
        padding: 8px 12px;
        font-size: 0.95rem;
    }
    
    .text-muted {
        color: rgba(255, 255, 255, 0.6) !important;
    }
    
    .animate-in {
        animation: fadeIn 0.5s ease-out forwards;
        opacity: 0;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }

    .dropdown-menu {
        background-color: rgba(93, 63, 159, 0.95);
        border: 1px solid rgba(255, 255, 255, 0.15);
        border-radius: 12px;
    }
    
    .dropdown-item {
        color: white;
        padding: 10px 20px;
    }
    
    .dropdown-item:hover {
        background-color: rgba(167, 139, 250, 0.3);
    }
    
    .dropdown-item i {
        margin-right: 12px;
        width: 20px;
        text-align: center;
    }
</style>

<div class="row justify-content-center mt-4">
    <div class="col-lg-12">
        <?= $this->include('Layout/msgStatus') ?>
    </div>

    <div class="col-lg-12">
        <div class="card shadow-sm animate-in">
            <div class="card-header text-white">
                <div class="row align-items-center">
                    <div class="col pt-1">
                        <i class="bi bi-robot me-2"></i> Telegram Bots Management
                    </div>
                    <div class="col text-end">
                        <a href="<?= site_url('bots/create') ?>" class="btn btn-success">
                            <i class="bi bi-plus-circle me-2"></i> Add New Bot
                        </a>
                    </div>
                </div>
            </div>
            
            <div class="card-body">
                <?php if (empty($bots)): ?>
                    <div class="text-center py-5">
                        <i class="bi bi-robot display-1 text-white-50"></i>
                        <h5 class="mt-3">No bots yet</h5>
                        <p class="text-white-50">Create your first Telegram bot to get started.</p>
                        <a href="<?= site_url('bots/create') ?>" class="btn btn-success">Create First Bot</a>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Bot Name</th>
                                    <th>Games</th>
                                    <th>Status</th>
                                    <th>Created</th>
                                    <th width="280">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($bots as $bot): ?>
                                <tr>
                                    <td><?= $bot['id'] ?></td>
                                    <td><strong>@<?= esc($bot['name']) ?></strong></td>
                                    <td>
                                        <?php 
                                        $gamesList = array_filter(array_map('trim', explode(',', $bot['games'] ?? '')));
                                        if (empty($gamesList)): 
                                        ?>
                                            <span class="text-white-50">— No games —</span>
                                        <?php else: 
                                            foreach ($gamesList as $game):
                                                if (!empty($game) && isset($game_list[$game])):
                                        ?>
                                                    <span class="game-badge"><?= esc($game_list[$game]) ?></span>
                                        <?php 
                                                endif;
                                            endforeach; 
                                        endif;
                                        ?>
                                    </td>
                                    <td>
                                        <span class="badge <?= $bot['status'] === 'active' ? 'status-active' : 'status-inactive' ?>">
                                            <?= $bot['status'] === 'active' ? 'Active' : 'Offline' ?>
                                        </span>
                                    </td>
                                    <td><small class="text-white-50"><?= $bot['created_at'] ?></small></td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <a href="<?= site_url('bots/edit/' . $bot['id']) ?>" class="btn btn-outline-info btn-action">
                                                <i class="bi bi-pencil-square"></i>
                                            </a>
                                            <a href="<?= site_url('bots/toggle/' . $bot['id']) ?>" class="btn btn-<?= $bot['status'] === 'active' ? 'warning' : 'success' ?> btn-action">
                                                <i class="bi bi-<?= $bot['status'] === 'active' ? 'pause' : 'play' ?>"></i>
                                            </a>
                                            <a href="<?= site_url('bots/reset/' . $bot['id']) ?>" class="btn btn-outline-primary btn-action" onclick="return confirm('Reset webhook?')">
                                                <i class="bi bi-arrow-repeat"></i>
                                            </a>
                                            <a href="<?= site_url('bots/delete/' . $bot['id']) ?>" class="btn btn-danger btn-action" onclick="return confirm('Delete permanently?')">
                                                <i class="bi bi-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>