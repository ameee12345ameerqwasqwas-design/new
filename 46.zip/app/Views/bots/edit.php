<?= $this->extend('Layout/Starter') ?>
<?= $this->section('content') ?>

<style>
    body {
        background-image: url('<?= base_url('assets/images/backround1.avif') ?>');
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        background-color: #24193d;
    }
    
    .card {
        background-color: rgba(93, 63, 159, 0.7) !important;
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 15px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        overflow: hidden;
        margin-bottom: 25px;
    }
    
    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 40px rgba(0, 0, 0, 0.4);
    }
    
    .card-header {
        background: linear-gradient(135deg, rgba(93, 63, 159, 0.6), rgba(80, 50, 140, 0.8)) !important;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        color: white !important;
        font-weight: 600;
        padding: 15px 20px;
    }
    
    .card-body {
        padding: 25px;
        color: white;
    }
    
    .form-control, .form-select {
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        color: white;
        border-radius: 10px;
        padding: 12px 16px;
    }
    
    .form-control:focus, .form-select:focus {
        background-color: rgba(255, 255, 255, 0.15);
        border-color: rgba(167, 139, 250, 0.5);
        color: white;
        box-shadow: 0 0 0 0.25rem rgba(167, 139, 250, 0.25);
    }
    
    .form-control::placeholder {
        color: rgba(255, 255, 255, 0.6);
    }
    
    .form-select option {
        background-color: rgba(93, 63, 159, 0.9);
        color: white;
    }
    
    .form-label {
        color: white;
        font-weight: 500;
        margin-bottom: 0.5rem;
    }
    
    .game-container {
        max-height: 420px;
        overflow-y: auto;
        padding-right: 10px;
    }
    
    .game-row {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 12px;
    }
    
    .btn-outline-light {
        color: white;
        border-color: rgba(255, 255, 255, 0.5);
    }
    
    .btn-outline-light:hover {
        background-color: rgba(255, 255, 255, 0.1);
        color: white;
    }
    
    .text-muted {
        color: rgba(255, 255, 255, 0.6) !important;
    }
    
    .animate-in {
        animation: fadeIn 0.5s ease-out forwards;
        opacity: 0;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }
</style>

<div class="row justify-content-center mt-4">
    <div class="col-lg-9">
        <?= $this->include('Layout/msgStatus') ?>
        
        <div class="card shadow-sm animate-in">
            <div class="card-header text-white">
                <i class="bi bi-pencil-square me-2"></i> Edit Bot
            </div>
            <div class="card-body">
                <form action="<?= site_url('bots/update/' . $bot['id']) ?>" method="post">
                    <?= csrf_field() ?>
                    
                    <div class="mb-4">
                        <label class="form-label">Bot Name <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control" 
                               value="<?= esc($bot['name']) ?>" required>
                    </div>

                    <!-- Registrator -->
                    <div class="mb-4">
                        <label class="form-label">Registrator <span class="text-danger">*</span></label>
                        <input type="text" name="registrator" class="form-control" 
                               value="<?= esc($bot['registrator'] ?? '') ?>" required>
                        <small class="text-muted">This name will be recorded in all keys generated from this bot</small>
                    </div>

                    <!-- Dynamic Games -->
                    <div class="mb-4">
                        <label class="form-label">Supported Games <span class="text-danger">*</span></label>
                        <div id="gamesContainer" class="game-container"></div>
                        <button type="button" id="addGameBtn" class="btn btn-outline-light btn-sm mt-2">
                            <i class="bi bi-plus-circle"></i> Add Another Game
                        </button>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Default Key Duration (hours)</label>
                        <input type="number" name="default_duration" class="form-control" 
                               value="<?= esc($bot['default_duration']) ?>" min="1" required>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Code Prefix (optional)</label>
                        <input type="text" name="prefix" class="form-control" 
                               value="<?= esc($bot['prefix'] ?? '') ?>" maxlength="20">
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Welcome Message (/start)</label>
                        <textarea name="welcome_message" class="form-control" rows="4"><?= esc($bot['welcome_message'] ?? '') ?></textarea>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Offline Message</label>
                        <textarea name="offline_message" class="form-control" rows="4"><?= esc($bot['offline_message'] ?? '') ?></textarea>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Bot Status</label>
                        <select name="status" class="form-select">
                            <option value="active" <?= $bot['status'] === 'active' ? 'selected' : '' ?>>Active</option>
                            <option value="inactive" <?= $bot['status'] === 'inactive' ? 'selected' : '' ?>>Inactive (Offline)</option>
                        </select>
                    </div>

                    <hr class="my-4">

                    <button type="submit" class="btn btn-outline-light w-100 py-3 fw-semibold">
                        <i class="bi bi-save me-2"></i> Save Changes
                    </button>
                </form>
            </div>
        </div>
        
        <div class="text-center mt-4">
            <a href="<?= site_url('bots') ?>" class="btn btn-outline-light">
                <i class="bi bi-arrow-left me-2"></i> Back to Bots List
            </a>
        </div>
    </div>
</div>

<script>
const allGames = <?= json_encode($game_list) ?>;
let selectedGames = <?= json_encode(array_filter(array_map('trim', explode(',', $bot['games'] ?? '')))) ?>;

function renderGameRows() {
    const container = document.getElementById('gamesContainer');
    container.innerHTML = '';

    selectedGames.forEach((val, index) => {
        const row = document.createElement('div');
        row.className = 'game-row';

        const select = document.createElement('select');
        select.className = 'form-select';
        select.name = 'games[]';
        select.required = true;

        const empty = document.createElement('option');
        empty.value = '';
        empty.textContent = '— Select Game —';
        select.appendChild(empty);

        Object.keys(allGames).forEach(key => {
            if (selectedGames.includes(key) && selectedGames.indexOf(key) !== index) return;
            const opt = document.createElement('option');
            opt.value = key;
            opt.textContent = allGames[key];
            if (key === val) opt.selected = true;
            select.appendChild(opt);
        });

        select.addEventListener('change', () => {
            selectedGames[index] = select.value;
            renderGameRows();
        });

        row.appendChild(select);

        if (selectedGames.length > 1) {
            const removeBtn = document.createElement('button');
            removeBtn.type = 'button';
            removeBtn.className = 'btn btn-danger btn-sm';
            removeBtn.innerHTML = '<i class="bi bi-trash"></i>';
            removeBtn.addEventListener('click', () => {
                selectedGames.splice(index, 1);
                renderGameRows();
            });
            row.appendChild(removeBtn);
        }

        container.appendChild(row);
    });
}

document.getElementById('addGameBtn').addEventListener('click', () => {
    if (selectedGames.length >= Object.keys(allGames).length) {
        alert('Maximum number of games reached!');
        return;
    }
    selectedGames.push('');
    renderGameRows();
});

renderGameRows();
</script>

<?= $this->endSection() ?>