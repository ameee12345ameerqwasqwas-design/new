<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>

<style>
    body {
        background-image: url('<?= base_url('assets/images/backround1.avif') ?>');
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        background-color: #24193d;
        margin: 0;
        padding: 0;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .login-container {
        display: flex;
        justify-content: center;
        align-items: center;
        width: 100%;
        padding: 20px;
    }
    
    .card {
        background-color: rgba(93, 63, 159, 0.7) !important;
        backdrop-filter: blur(15px);
        -webkit-backdrop-filter: blur(15px);
        border-radius: 25px;
        border: 1px solid rgba(255, 255, 255, 0.15);
        box-shadow: 0 25px 45px rgba(0, 0, 0, 0.25), inset 0 0 20px rgba(255, 255, 255, 0.05);
        padding: 50px;
        color: #fff;
        width: 100%;
        max-width: 450px;
        transform-style: preserve-3d;
        perspective: 1000px;
        transition: all 0.5s ease;
        text-align: center;
    }
    
    .card-header {
        background-color: transparent;
        border-bottom: none;
        color: white;
        text-align: center;
        font-size: 24px;
        padding-top: 20px;
    }
    
    .card-body {
        padding: 50px;
    }
    
    .form-control {
        background-color: rgba(93, 63, 159, 0.4);
        border: 1px solid rgba(255, 255, 255, 0.2);
        color: white !important;
        border-radius: 50px;
        padding: 12px 20px;
        transition: all 0.3s ease;
    }
    
    .form-control::placeholder {
        color: rgba(255, 255, 255, 0.6);
    }
    
    .form-control:focus {
        background-color: rgba(93, 63, 159, 0.6);
        box-shadow: 0 0 0 0.25rem rgba(255, 255, 255, 0.1);
        border-color: rgba(255, 255, 255, 0.3);
    }
    
    label {
        color: white;
        margin-left: 10px;
        font-size: 14px;
    }
    
    .form-check-label {
        color: white;
    }
    
    .form-check-input {
        background-color: rgba(93, 63, 159, 0.4);
        border-color: rgba(255, 255, 255, 0.3);
    }
    
    .form-check-input:checked {
        background-color: #8e65e3;
    }
    
    .btn-login {
        background-color: white;
        color: #5d3f9f;
        border-radius: 50px;
        padding: 10px;
        font-weight: bold;
        width: 100%;
        border: none;
        transition: all 0.3s;
        opacity: 0;
        transform: translateY(10px);
    }
    
    .btn-login:hover {
        background-color: #f0f0f0;
        transform: translateY(-2px);
    }
    
    .forgot-password {
        color: white;
        text-decoration: none;
        font-size: 14px;
    }
    
    .forgot-password:hover {
        text-decoration: underline;
        color: white;
    }
    
    .register-link {
        color: white;
        text-decoration: none;
    }
    
    .register-link:hover {
        text-decoration: underline;
    }
    
    .after-card {
        color: white !important;
    }
    
    .after-card a {
        color: #a78bfa !important;
    }
    
    .input-icon {
        position: relative;
    }
    
    .input-icon i {
        position: absolute;
        right: 15px;
        top: 42px;
        color: white;
        cursor: pointer;
    }
    
    .password-box {
        opacity: 0;
        transform: translateY(10px);
        transition: all 0.3s ease;
        height: 0;
        overflow: hidden;
    }
    
    .password-box.visible {
        opacity: 1;
        transform: translateY(0);
        height: auto;
        overflow: visible;
    }
    
    .social-icons {
        margin-top: 15px;
        text-align: center;
    }
    
    .social-icon {
        display: inline-flex;
        justify-content: center;
        align-items: center;
        margin: 0 15px;
        color: #fff;
        font-size: 28px;
        width: 60px;
        height: 60px;
        border-radius: 50%;
        background: rgba(93, 63, 159, 0.7);
        transition: all 0.3s ease;
        cursor: pointer;
    }
    
    .social-icon:hover {
        background: #0088cc;
        transform: scale(1.2);
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
    }
    
    .social-icon i {
        display: inline-block;
        vertical-align: middle;
    }
    
    .hidden {
        display: none;
    }
    
    .shake {
        animation: shake 0.5s;
    }
    
    @keyframes shake {
        0%, 100% { transform: translateX(0); }
        10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
        20%, 40%, 60%, 80% { transform: translateX(5px); }
    }
    
    @keyframes float {
        0%, 100% { transform: translateY(0); }
        50% { transform: translateY(-10px); }
    }
    
    @media (max-width: 768px) {
        .card {
            padding: 30px;
            max-width: 380px;
        }
        
        .card-body {
            padding: 30px;
        }
        
        .btn-login {
            padding: 12px;
        }
        
        .social-icon {
            width: 50px;
            height: 50px;
            font-size: 24px;
            margin: 0 10px;
        }
    }
    
    @media (max-width: 576px) {
        .login-container {
            padding: 10px;
        }
        
        .card {
            padding: 20px;
            border-radius: 20px;
        }
        
        .card-header h2 {
            font-size: 20px;
        }
        
        .form-control {
            padding: 10px 16px;
        }
        
        .social-icons {
            margin-top: 10px;
        }
    }
</style>
<?php 
$encoded_url = 'aHR0cHM6Ly90Lm1lL0hJTUEzNWJvdA==';
$decoded_url = base64_decode($encoded_url);
?>
<div class="login-container">
    <div class="card shadow-sm mb-5" id="loginBox">
        <div class="card-header">
            <h2>Welcome Back</h2>
        </div>
        <div class="card-body">
            <?= form_open() ?>
            <div class="form-group mb-4 input-icon">
                <label for="username">Username</label>
                <input type="text" class="form-control" name="username" id="username" aria-describedby="help-username" placeholder="Your username" required minlength="4" value="<?= esc($username_value) ?>">
                <i class="bi bi-person-fill"></i>
                <?php if (!empty($errors['username'])) : ?>
                    <small id="help-username" class="form-text text-warning"><?= esc($errors['username']) ?></small>
                <?php endif; ?>
            </div>
            
            <div class="password-box hidden" id="passwordBox">
                <div class="form-group mb-4 input-icon">
                    <label for="password">Password</label>
                    <input type="password" class="form-control" name="password" id="password" aria-describedby="help-password" placeholder="Your password" required minlength="6">
                    <i class="bi bi-eye-fill" id="togglePassword"></i>
                    <?php if (!empty($errors['password'])) : ?>
                        <small id="help-password" class="form-text text-warning"><?= esc($errors['password']) ?></small>
                    <?php endif; ?>
                </div>
                
                <input type="hidden" name="ip" value="<?= esc($user_agent) ?>" id="ip">
                
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input" name="stay_log" id="stay_log" value="yes" <?= $stay_log_checked ?>>
                        <label class="form-check-label" for="stay_log" data-bs-toggle="tooltip" data-bs-placement="top" title="Keep session more than 30 minutes">
                            Remember me
                        </label>
                    </div>
                    <a href="<?= $decoded_url ?>" class="forgot-password" target="_blank" rel="noopener noreferrer">Forgot password?</a>
                </div>
            </div>
            
            <div class="form-group mb-3">
                <button type="submit" class="btn-login hidden" id="loginBtn">Login</button>
            </div>
            
            <div class="text-center mt-3">
                <p class="text-white mb-0">
                    Don't have an account? <a href="<?= site_url('register') ?>" class="register-link">Register</a>
                </p>
                <div class="social-icons">
                    <a href="https://t.me/x3_2r" target="_blank" class="social-icon telegram">
                        <i class="fab fa-telegram"></i>
                    </a>
                </div>
                <small class="px-auto p-2 rounded">
                    TO GET VIP PANEL DM :- 
                    <a href="<?= $decoded_url ?>" class="text-danger">@x3_2r</a>
                </small>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const usernameInput = document.getElementById('username');
        const passwordBox = document.getElementById('passwordBox');
        const loginBtn = document.getElementById('loginBtn');
        const togglePassword = document.getElementById('togglePassword');
        const passwordInput = document.getElementById('password');
        const loginBox = document.getElementById('loginBox');

        usernameInput.addEventListener('input', function() {
            if (this.value.length >= 3) {
                passwordBox.classList.remove('hidden');
                setTimeout(() => {
                    passwordBox.classList.add('visible');
                }, 10);
            } else if (this.value.length < 3 && !passwordBox.classList.contains('hidden')) {
                passwordBox.classList.remove('visible');
                setTimeout(() => {
                    passwordBox.classList.add('hidden');
                    loginBtn.classList.add('hidden');
                }, 300);
            }
        });

        passwordInput.addEventListener('input', function() {
            if (this.value.length >= 1) {
                loginBtn.classList.remove('hidden');
                setTimeout(() => {
                    loginBtn.style.opacity = '1';
                    loginBtn.style.transform = 'translateY(0)';
                }, 10);
            } else {
                loginBtn.style.opacity = '0';
                loginBtn.style.transform = 'translateY(10px)';
                setTimeout(() => {
                    loginBtn.classList.add('hidden');
                }, 300);
            }
        });

        togglePassword.addEventListener('click', function() {
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            this.classList.toggle('bi-eye-fill');
            this.classList.toggle('bi-eye-slash-fill');
        });

        usernameInput.addEventListener('animationend', function() {
            this.classList.remove('shake');
        });

        passwordInput.addEventListener('animationend', function() {
            this.classList.remove('shake');
        });

        setInterval(() => {
            loginBox.style.animation = 'float 8s ease-in-out infinite';
        }, 0);
    });
</script>

<?= $this->endSection() ?>