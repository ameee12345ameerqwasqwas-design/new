<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>

<style>
    body {
        background-image: url('<?= base_url('assets/images/backround1.avif') ?>');
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        background-color: #24193d;
        margin: 0;
        padding: 0;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .register-container {
        display: flex;
        justify-content: center;
        align-items: center;
        width: 100%;
        padding: 20px;
    }
    
    .card {
        background-color: rgba(93, 63, 159, 0.7) !important;
        backdrop-filter: blur(15px);
        -webkit-backdrop-filter: blur(15px);
        border-radius: 25px;
        border: 1px solid rgba(255, 255, 255, 0.15);
        box-shadow: 0 25px 45px rgba(0, 0, 0, 0.25), inset 0 0 20px rgba(255, 255, 255, 0.05);
        padding: 50px;
        color: #fff;
        width: 100%;
        max-width: 480px;
        text-align: center;
    }
    
    .card-header {
        background-color: transparent;
        border-bottom: none;
        color: white;
        text-align: center;
        font-size: 24px;
        padding-top: 20px;
        margin-bottom: 20px;
    }
    
    .card-body {
        padding: 30px 40px;
    }
    
    .form-control {
        background-color: rgba(93, 63, 159, 0.4);
        border: 1px solid rgba(255, 255, 255, 0.2);
        color: white !important;
        border-radius: 50px;
        padding: 12px 20px;
        transition: all 0.3s ease;
    }
    
    .form-control::placeholder {
        color: rgba(255, 255, 255, 0.6);
    }
    
    .form-control:focus {
        background-color: rgba(93, 63, 159, 0.6);
        box-shadow: 0 0 0 0.25rem rgba(255, 255, 255, 0.1);
        border-color: rgba(255, 255, 255, 0.3);
    }
    
    label {
        color: white;
        margin-left: 10px;
        font-size: 14px;
        font-weight: 500;
        display: block;
        text-align: left;
    }
    
    .btn-register {
        background-color: white;
        color: #5d3f9f;
        border-radius: 50px;
        padding: 14px;
        font-weight: bold;
        width: 100%;
        border: none;
        transition: all 0.3s;
        font-size: 1.1rem;
    }
    
    .btn-register:hover {
        background-color: #f0f0f0;
        transform: translateY(-2px);
    }
    
    .after-card {
        color: white !important;
        margin-top: 20px;
    }
    
    .after-card a {
        color: #a78bfa !important;
        text-decoration: none;
        font-weight: 600;
    }
    
    .input-icon {
        position: relative;
    }
    
    .input-icon i {
        position: absolute;
        right: 18px;
        top: 42px;
        color: white;
        font-size: 1.1rem;
        cursor: pointer;
        transition: color 0.3s ease;
    }

    .hidden-field {
        display: none;
        opacity: 0;
        transform: translateY(10px);
        transition: all 0.4s ease;
    }
    
    .visible-field {
        display: block !important;
        opacity: 1 !important;
        transform: translateY(0) !important;
    }

    @media (max-width: 768px) {
        .card { padding: 40px; max-width: 400px; }
    }
</style>

<div class="register-container">
    <div class="card shadow-sm">
        
        <div class="card-header">Register</div>
        
        <div class="card-body">
            <?= form_open() ?>

            <div class="form-group mb-3 input-icon" id="box-username">
                <label for="username">Username</label>
                <input type="text" class="form-control mt-2" name="username" id="username" placeholder="Your username" minlength="4" maxlength="24" value="<?= esc($username_value) ?>" required>
                <i class="bi bi-person-fill"></i>
            </div>
            
            <div class="form-group mb-3 input-icon hidden-field" id="box-fullname">
                <label for="fullname">Fullname</label>
                <input type="text" class="form-control mt-2" name="fullname" id="fullname" placeholder="Your fullname" minlength="4" maxlength="24" value="<?= esc($fullname_value) ?>">
                <i class="bi bi-person-badge-fill"></i>
            </div>
            
            <div class="form-group mb-3 input-icon hidden-field" id="box-password">
                <label for="password">Password</label>
                <input type="password" class="form-control mt-2" name="password" id="password" placeholder="Enter Password" minlength="6">
                <i class="bi bi-lock-fill toggle-password"></i>
            </div>
            
            <div class="form-group mb-3 input-icon hidden-field" id="box-password2">
                <label for="password2">Confirm Password</label>
                <input type="password" class="form-control mt-2" name="password2" id="password2" placeholder="Confirm password">
                <i class="bi bi-lock-fill toggle-password2"></i>
            </div>
            
            <div class="hidden-field" id="box-final">
                <div class="form-group mb-4 input-icon">
                    <label for="referral">Referral Code</label>
                    <input type="text" class="form-control mt-2" name="referral" id="referral" placeholder="Your Referral Code" value="<?= esc($referral_value) ?>" maxlength="25">
                    <i class="bi bi-gift-fill"></i>
                </div>
                
                <div class="form-group mt-4">
                    <button type="submit" class="btn-register">Register</button>
                </div>
            </div>
            
            <?= form_close() ?>
            
            <p class="text-center after-card mt-4">
                <small>Already have an account? <a href="<?= site_url('login') ?>">Login here</a></small>
            </p>
        </div>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('js') ?>
<script>
    $(document).ready(function() {
        function setupToggle(currentInput, nextBox, minLen) {
            $(currentInput).on('input', function() {
                if ($(this).val().length >= minLen) {
                    $(nextBox).addClass('visible-field');
                } else {
                    $(nextBox).removeClass('visible-field');
                }
            });
        }

        setupToggle('#username', '#box-fullname', 3);
        setupToggle('#fullname', '#box-password', 3);
        setupToggle('#password', '#box-password2', 6);
        setupToggle('#password2', '#box-final', 6);

        $(document).on('click', '.toggle-password', function() {
            $(this).toggleClass("bi-lock-fill bi-unlock-fill");
            var input = $("#password");
            input.attr('type') === 'password' ? input.attr('type','text') : input.attr('type','password');
        });
        
        $(document).on('click', '.toggle-password2', function() {
            $(this).toggleClass("bi-lock-fill bi-unlock-fill");
            var input = $("#password2");
            input.attr('type') === 'password' ? input.attr('type','text') : input.attr('type','password');
        });
    });
</script>
<?= $this->endSection() ?>