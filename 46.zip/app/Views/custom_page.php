<!doctype html>
<html dir="rtl" lang="ar">
<head>
    <meta charset="UTF-8">
    <meta content="width=device-width,initial-scale=1" name="viewport">
    <title>𝐀𝐑𝟑𝐌𝐎𝐃𝐗</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #0f0d18; /* لون خلفية غامق جداً */
            background-image: linear-gradient(135deg, #1a1625 0%, #0f0d18 100%);
            color: #fff;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .hero-card {
            background: rgba(30, 25, 50, 0.6);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid rgba(167, 139, 250, 0.15);
            border-radius: 30px;
            max-width: 550px;
            width: 100%;
            padding: 50px 30px;
            text-align: center;
            box-shadow: 0 25px 50px rgba(0,0,0,0.5);
            position: relative;
            overflow: hidden;
        }

        /* إضافة لمسة جمالية للخلفية بدون صورة */
        .hero-card::after {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(124, 58, 237, 0.1) 0%, transparent 60%);
            z-index: -1;
        }

        h1 {
            font-size: 3.5rem;
            font-weight: 800;
            background: linear-gradient(135deg, #a78bfa, #60a5fa);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 15px;
            letter-spacing: 2px;
            text-shadow: 0 0 15px rgba(167, 139, 250, 0.3);
        }

        .subtitle {
            font-size: 1.15rem;
            margin-bottom: 45px;
            color: #b0b0b0;
            line-height: 1.6;
        }

        /* زر التواصل الأساسي */
        .main-button {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            background: linear-gradient(135deg, #7c3aed, #5b21b6);
            color: white;
            text-decoration: none;
            padding: 20px;
            border-radius: 18px;
            font-size: 1.35rem;
            font-weight: 700;
            transition: 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            box-shadow: 0 10px 25px rgba(124, 58, 237, 0.4);
            margin-bottom: 30px;
        }

        .main-button:hover {
            transform: translateY(-5px) scale(1.03);
            box-shadow: 0 15px 35px rgba(124, 58, 237, 0.6);
        }

        .links-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin-bottom: 40px;
        }

        .sub-link {
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid rgba(167, 139, 250, 0.1);
            padding: 16px;
            border-radius: 14px;
            color: #ddd;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            font-size: 1.05rem;
            font-weight: 500;
            transition: 0.3s ease;
        }

        .sub-link:hover
