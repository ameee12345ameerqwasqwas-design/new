<?php $uri = service('uri'); ?>

<style>
:root {
    --primary-color: #5d3f9f; 
    --accent-color: #0dcaf0;  
    --sidebar-bg: rgba(36, 25, 61, 0.65); 
    --sidebar-border: rgba(255, 255, 255, 0.1); 
    --text-light: #e6e6e6;
    --text-muted: #a0a0a0;
    --hover-bg: rgba(255, 255, 255, 0.1);
}

* {
    box-sizing: border-box;
    -webkit-tap-highlight-color: transparent;
}

body {
    margin: 0;
    padding: 0;
    overflow-x: hidden; 
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

.menu-button {
    position: fixed;
    right: 25px;
    bottom: 25px;
    width: 60px;
    height: 60px;
    border-radius: 50%;
    background: rgba(93, 63, 159, 0.8);
    backdrop-filter: blur(5px);
    border: 1px solid rgba(255, 255, 255, 0.2);
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 6px;
    cursor: pointer;
    z-index: 1000;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
    transition: all 0.3s ease;
}

.menu-button span {
    display: block;
    width: 24px;
    height: 2px;
    background: #fff;
    border-radius: 1px;
    transition: all 0.3s ease;
}

.menu-button:hover {
    transform: scale(1.1);
    background: #5d3f9f;
    border-color: #0dcaf0;
    box-shadow: 0 0 15px rgba(13, 202, 240, 0.4);
}

.menu-button.active {
    background: #24193d;
    border-color: #0dcaf0;
}

.menu-button.active span:nth-child(1) {
    transform: rotate(45deg) translate(5px, 5px);
    background: #0dcaf0;
}
.menu-button.active span:nth-child(2) {
    opacity: 0;
}
.menu-button.active span:nth-child(3) {
    transform: rotate(-45deg) translate(5px, -5px);
    background: #0dcaf0;
}

.sidebar-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(15, 10, 30, 0.3);
    backdrop-filter: blur(0px); 
    -webkit-backdrop-filter: blur(0px);
    opacity: 0;
    visibility: hidden;
    transition: all 0.4s ease;
    z-index: 999;
    pointer-events: none;
}

.sidebar-overlay.active {
    opacity: 1;
    visibility: visible;
    pointer-events: auto;
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
}

.sidebar {
    position: fixed;
    top: 0;
    bottom: 0;
    right: -100%;
    width: 320px;
    background: var(--sidebar-bg);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    border-left: 1px solid var(--sidebar-border);
    box-shadow: -10px 0 30px rgba(0, 0, 0, 0.5);
    z-index: 1000;
    display: flex;
    flex-direction: column;
    transition: right 0.4s cubic-bezier(0.19, 1, 0.22, 1);
    overflow: hidden;
}

.sidebar.active {
    right: 0;
}

.sidebar-inner {
    flex: 1;
    overflow-y: auto;
    padding: 25px;
    height: 100%;
}

.sidebar-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 25px;
    padding-bottom: 15px;
    border-bottom: 1px solid rgba(255,255,255,0.1);
}

.brand-wrapper {
    display: flex;
    align-items: center;
    gap: 12px;
}

.brand-logo {
    width: 45px;
    height: 45px;
    border-radius: 12px;
    border: 1px solid rgba(255,255,255,0.2);
    padding: 2px;
    background: rgba(255, 255, 255, 0.05);
}

.brand-name {
    font-size: 1.3rem;
    font-weight: 600;
    color: #fff;
    text-shadow: 0 0 10px rgba(93, 63, 159, 0.5);
}

.close-sidebar {
    width: 35px;
    height: 35px;
    border-radius: 50%;
    background: rgba(255,255,255,0.05);
    border: 1px solid rgba(255,255,255,0.1);
    color: #e6e6e6;
    cursor: pointer;
    transition: all 0.2s ease;
    display: flex;
    align-items: center;
    justify-content: center;
}

.close-sidebar:hover {
    transform: rotate(90deg);
    background: var(--primary-color);
    color: white;
}

.user-profile-card {
    display: flex;
    align-items: center;
    gap: 15px;
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 15px;
    padding: 20px;
    margin-bottom: 25px;
    transition: transform 0.3s ease;
}

.user-profile-card:hover {
    background: rgba(255, 255, 255, 0.08);
    border-color: rgba(13, 202, 240, 0.3);
}

.avatar-icon {
    width: 50px;
    height: 50px;
    border-radius: 12px;
    background: linear-gradient(135deg, #5d3f9f, #0dcaf0);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 1.2rem;
    flex-shrink: 0;
    box-shadow: 0 4px 10px rgba(0,0,0,0.2);
}

.menu-section-title {
    font-size: 0.8rem;
    color: #0dcaf0;
    text-transform: uppercase;
    letter-spacing: 1.5px;
    margin: 20px 0 10px;
    padding-left: 10px;
    font-weight: 700;
    opacity: 0.8;
}

.sidebar a {
    display: flex;
    align-items: center;
    padding: 14px 18px;
    color: #e6e6e6;
    text-decoration: none;
    border-radius: 12px;
    margin-bottom: 8px;
    background: transparent;
    border: 1px solid transparent;
    font-size: 0.95rem;
    transition: all 0.2s ease;
}

.sidebar a i {
    font-size: 1.1rem;
    color: rgba(255,255,255,0.7);
    width: 25px;
    text-align: center;
    margin-right: 15px;
    transition: all 0.2s ease;
}

.sidebar a:hover {
    background: rgba(255, 255, 255, 0.1);
    transform: translateX(5px);
    color: white;
    border-color: rgba(255, 255, 255, 0.1);
}

.sidebar a:hover i {
    color: #0dcaf0;
    text-shadow: 0 0 8px #0dcaf0;
}

.sidebar a.active {
    background: rgba(93, 63, 159, 0.4);
    border: 1px solid rgba(13, 202, 240, 0.3);
    color: white;
    box-shadow: 0 4px 15px rgba(0,0,0,0.2);
}

.sidebar a.active i {
    color: #0dcaf0;
}

.sidebar-divider {
    height: 1px;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
    margin: 20px 0;
}

.sidebar-footer {
    margin-top: 30px;
    padding-top: 20px;
    border-top: 1px solid rgba(255,255,255,0.1);
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.sidebar-footer a:first-child {
    background: rgba(0, 131, 255, 0.1);
    color: #4da6ff;
    border: 1px solid rgba(0, 131, 255, 0.2);
}

.sidebar-footer a:last-child {
    background: rgba(255, 107, 53, 0.1);
    color: #ff8c61;
    border: 1px solid rgba(255, 107, 53, 0.2);
}

.sidebar-inner::-webkit-scrollbar {
    width: 4px;
}
.sidebar-inner::-webkit-scrollbar-track {
    background: transparent;
}
.sidebar-inner::-webkit-scrollbar-thumb {
    background: rgba(255,255,255,0.2);
    border-radius: 2px;
}

@media (max-width: 768px) {
    .sidebar {
        width: 85%;
        max-width: 320px;
    }
    
    .sidebar-overlay.active {
        backdrop-filter: blur(10px);
        -webkit-backdrop-filter: blur(10px);
    }
}
</style>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<div class="sidebar-overlay" id="sidebarOverlay"></div>

<?php if ($uri->getSegment(1) != 'login') : ?>
    <div class="menu-button" id="menuButton" aria-label="Toggle menu" data-sound="trigger">
        <span></span><span></span><span></span>
    </div>
<?php endif; ?>

<nav class="sidebar" id="sidebar" role="navigation" aria-label="Main navigation">
    <div class="sidebar-inner">
        <div class="sidebar-header">
            <div class="brand-wrapper">
                <img src="/assets/favicon.ico" alt="<?= BASE_NAME ?> Logo" class="brand-logo" loading="lazy">
                <span class="brand-name"><?= BASE_NAME ?></span>
            </div>
            <button class="close-sidebar" id="closeSidebar" aria-label="Close menu" data-sound="trigger">
                <i class="fas fa-times"></i>
            </button>
        </div>

        <?php if (session()->has('userid')) : ?>
            <div class="user-profile-card">
                <div class="avatar-icon" aria-hidden="true">
                    <i class="fas fa-user-secret"></i>
                </div>
                <div>
                    <h4 style="margin:0;color:white;font-size:1.1rem;font-weight:600;">
                        <?= getName($user) ?>
                    </h4>
                    <span style="font-size:0.75rem;padding:4px 12px;border-radius:50px;background:rgba(13, 202, 240, 0.2);color:#0dcaf0;display:inline-block;margin-top:6px;border:1px solid rgba(13, 202, 240, 0.3);">
                        <?= getLevel($user->level) ?>
                    </span>
                    <span style="font-size:0.75rem;padding:4px 12px;border-radius:50px;background:rgba(255, 193, 7, 0.2);color:#ffc107;display:inline-block;margin-top:6px;border:1px solid rgba(255, 193, 7, 0.3); margin-left:5px;">
                        <i class="bi bi-wallet"></i> <?= $user->saldo ?> 
                    </span>
                </div>
            </div>

            <span class="menu-section-title">Main Menu</span>
            <a href="<?= site_url('dashboard') ?>" 
               class="<?= $uri->getSegment(1) == 'dashboard' ? 'active' : '' ?>" 
               data-sound="hover">
                <i class="fas fa-home"></i><span>Home</span>
            </a>
            <a href="<?= site_url('keys') ?>" 
               class="<?= ($uri->getSegment(1) == 'keys' && $uri->getSegment(2) == '') ? 'active' : '' ?>" 
               data-sound="hover">
                <i class="fas fa-key"></i><span>Keys</span>
            </a>
            <a href="<?= site_url('keys/generate') ?>" 
               class="<?= $uri->getSegment(2) == 'generate' ? 'active' : '' ?>" 
               data-sound="hover">
                <i class="fas fa-plus-circle"></i><span>Generate</span>
            </a>

            <div class="sidebar-divider"></div>

            <span class="menu-section-title">System</span>
            <a href="<?= site_url('settings') ?>" 
               class="<?= $uri->getSegment(1) == 'settings' ? 'active' : '' ?>" 
               data-sound="hover">
                <i class="fas fa-cog"></i><span>Settings</span>
            </a>

            <?php if ($user->level == 1) : ?>
                <a href="<?= site_url('Server') ?>" 
                   class="<?= $uri->getSegment(1) == 'Server' ? 'active' : '' ?>" 
                   data-sound="hover">
                    <i class="fas fa-server"></i><span>Online System</span>
                </a>

                <a href="<?= site_url('lib') ?>" 
                   class="<?= $uri->getSegment(1) == 'lib' ? 'active' : '' ?>" 
                   data-sound="hover">
                    <i class="fas fa-folder-open"></i><span>File Manager</span>
                </a>
                <a href="<?= site_url('bots') ?>" 
                    class="<?= $uri->getSegment(1) == 'bots' ? 'active' : '' ?>" 
                    data-sound="hover">
                    <i class="fas fa-robot"></i><span>Bots</span>
                </a>
                
                <a href="<?= site_url('panelsettings') ?>" 
                   class="<?= $uri->getSegment(1) == 'panelsettings' ? 'active' : '' ?>" 
                   data-sound="hover">
                    <i class="fas fa-cogs"></i><span>Panel Settings</span>
                </a>

                <a href="<?= site_url('admin/manage-users') ?>" 
                   class="<?= ($uri->getSegment(1) == 'admin' && $uri->getSegment(2) == 'manage-users') ? 'active' : '' ?>" 
                   data-sound="hover">
                    <i class="fas fa-users"></i><span>Manage Users</span>
                </a>

                <a href="<?= site_url('admin/create-referral') ?>" 
                   class="<?= ($uri->getSegment(1) == 'admin' && $uri->getSegment(2) == 'create-referral') ? 'active' : '' ?>" 
                   data-sound="hover">
                    <i class="fas fa-user-plus"></i><span>Create Referral</span>
                </a>
            <?php endif; ?>

            <div class="sidebar-footer">
                <a href="#" id="link1" target="_blank" rel="noopener noreferrer" data-sound="hover">
                    <i class="fab fa-telegram"></i><span>Developer</span>
                </a>
                <a href="<?= site_url('logout') ?>" data-sound="out">
                    <i class="fas fa-sign-out-alt"></i><span>Logout</span>
                </a>
            </div>
        <?php endif; ?>
    </div>
</nav>

<script>

const AudioEngine = {
    ctx: null,
    masterGain: null,
    init() {
        if (!this.ctx) {
            this.ctx = new (window.AudioContext || window.webkitAudioContext)();
            this.masterGain = this.ctx.createGain();
            this.masterGain.connect(this.ctx.destination);
            this.masterGain.gain.value = 0.1; 
        }
        if (this.ctx.state === 'suspended') this.ctx.resume();
    },
    play(freq, type = 'sine', duration = 0.1, vol = 1) {
        try {
            this.init();
            const t = this.ctx.currentTime;
            const osc = this.ctx.createOscillator();
            const g = this.ctx.createGain();
            osc.type = type;
            osc.frequency.setValueAtTime(freq, t);
            g.gain.setValueAtTime(0, t);
            g.gain.linearRampToValueAtTime(vol, t + 0.01);
            g.gain.exponentialRampToValueAtTime(0.0001, t + duration);
            osc.connect(g);
            g.connect(this.masterGain);
            osc.start(t);
            osc.stop(t + duration);
            osc.onended = () => { osc.disconnect(); g.disconnect(); };
        } catch(e) {}
    },
    trigger(name) {
        switch(name) {
            case 'hover': this.play(800, 'sine', 0.05, 0.2); break;
            case 'trigger': this.play(400, 'sine', 0.1, 0.4); break;
            case 'out': this.play(150, 'sawtooth', 0.4, 0.3); break;
        }
    }
};

let isSidebarOpen = false;
const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('sidebarOverlay');
const menuButton = document.getElementById('menuButton');
const closeButton = document.getElementById('closeSidebar');

function toggleSidebar() {
    isSidebarOpen = !isSidebarOpen;
    
    if (isSidebarOpen) {
        AudioEngine.trigger('trigger'); 
        sidebar.classList.add('active');
        overlay.classList.add('active');
        if (menuButton) menuButton.classList.add('active');
        
        document.body.style.overflow = 'hidden';
        
        setTimeout(() => {
            const items = document.querySelectorAll('.sidebar a, .user-profile-card');
            items.forEach((item, index) => {
                item.style.opacity = '0';
                item.style.transform = 'translateX(20px)';
                
                setTimeout(() => {
                    item.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
                    item.style.opacity = '1';
                    item.style.transform = 'translateX(0)';
                }, index * 40);
            });
        }, 100);
        
    } else {
        AudioEngine.trigger('trigger'); 
        sidebar.classList.remove('active');
        overlay.classList.remove('active');
        if (menuButton) menuButton.classList.remove('active');
        
        document.body.style.overflow = '';
        
        setTimeout(() => {
            const items = document.querySelectorAll('.sidebar a, .user-profile-card');
            items.forEach(item => {
                item.style.opacity = '';
                item.style.transform = '';
                item.style.transition = '';
            });
        }, 300);
    }
}

function initSidebar() {
    if (menuButton) menuButton.addEventListener('click', toggleSidebar);
    if (closeButton) closeButton.addEventListener('click', toggleSidebar);
    if (overlay) overlay.addEventListener('click', toggleSidebar);
    
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && isSidebarOpen) toggleSidebar();
    });
    
    if ('ontouchstart' in window) {
        let startX = 0;
        sidebar.addEventListener('touchstart', (e) => { startX = e.touches[0].clientX; }, { passive: true });
        sidebar.addEventListener('touchend', (e) => {
            if (!isSidebarOpen) return;
            const endX = e.changedTouches[0].clientX;
            if (startX - endX > 80) toggleSidebar(); 
        }, { passive: true });
        
        document.querySelectorAll('.sidebar a').forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth <= 768) setTimeout(toggleSidebar, 150);
            });
        });
    }
    
    window.addEventListener('resize', () => {
        if (window.innerWidth > 768 && isSidebarOpen) toggleSidebar();
    });
}

document.querySelectorAll('[data-sound]').forEach(el => {
    el.addEventListener('mouseenter', () => AudioEngine.trigger(el.dataset.sound));
});

document.addEventListener('DOMContentLoaded', () => {
    initSidebar();
});
const encoded = "aHR0cHM6Ly90Lm1lL0hJTUEzNWJvdA==";
document.getElementById("link1").href = atob(encoded);
</script>