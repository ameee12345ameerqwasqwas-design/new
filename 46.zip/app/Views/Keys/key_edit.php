<?= $this->extend('Layout/Starter') ?>
<?= $this->section('content') ?>

<style>
    body {
        background-image: url('<?= base_url('assets/images/backround1.avif') ?>');
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        background-color: #1a0f33;
        min-height: 100vh;
    }
    
    .card {
        background-color: rgba(75, 55, 130, 0.85) !important;
        backdrop-filter: blur(12px);
        border: 1px solid rgba(180, 150, 255, 0.2);
        border-radius: 18px;
        box-shadow: 0 10px 35px rgba(0, 0, 0, 0.4);
        transition: all 0.3s ease;
        overflow: hidden;
        margin-bottom: 30px;
    }
    
    .card:hover {
        transform: translateY(-8px);
        box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5);
        border-color: rgba(180, 150, 255, 0.4);
    }
    
    .card-header {
        background: linear-gradient(135deg, rgba(90, 65, 145, 0.7), rgba(70, 50, 120, 0.9)) !important;
        border-bottom: 1px solid rgba(180, 150, 255, 0.3);
        color: #ffffff !important;
        font-weight: 600;
        padding: 18px 25px;
        letter-spacing: 0.5px;
    }
    
    .card-body {
        padding: 25px;
        color: #f0e6ff;
    }
    
    .form-control, .form-select {
        background-color: rgba(255, 255, 255, 0.12);
        border: 1px solid rgba(180, 150, 255, 0.4);
        color: #ffffff;
        border-radius: 10px;
        transition: all 0.3s ease;
    }
    
    .form-control:focus, .form-select:focus {
        background-color: rgba(255, 255, 255, 0.18);
        border-color: #b8a0ff;
        box-shadow: 0 0 0 0.25rem rgba(184, 160, 255, 0.3);
        color: #ffffff;
    }
    
    .form-control::placeholder {
        color: rgba(255, 255, 255, 0.65);
    }
    
    .form-select option {
        background-color: #4b3782;
        color: #ffffff;
    }
    
    .form-label {
        color: #e0d0ff;
        font-weight: 500;
        margin-bottom: 0.7rem;
    }
    
    .form-label i {
        margin-right: 8px;
        opacity: 0.9;
    }
    
    .btn-outline-info {
        color: #a8f0ff;
        border-color: #6cd4ff;
        transition: all 0.3s ease;
    }
    
    .btn-outline-info:hover {
        background-color: rgba(108, 212, 255, 0.25);
        color: #ffffff;
        border-color: #a8f0ff;
        box-shadow: 0 0 15px rgba(108, 212, 255, 0.3);
    }
    
    .btn-outline-light {
        color: #e0d0ff;
        border-color: rgba(224, 208, 255, 0.6);
    }
    
    .btn-outline-light:hover {
        background-color: rgba(224, 208, 255, 0.15);
        color: #ffffff;
        border-color: #e0d0ff;
    }
    
    .text-muted {
        color: #c5b0ff !important;
    }
    
    .maxDev {
        background-color: rgba(140, 110, 255, 0.25) !important;
        border: 1px solid rgba(170, 140, 255, 0.5);
        color: #e0d0ff;
        padding: 6px 12px !important;
        border-radius: 50px !important;
        font-weight: 500;
        font-size: 0.9rem;
    }
    
    textarea {
        min-height: 120px;
        resize: vertical;
    }
    
    .badge.bg-warning {
        background-color: #ffb84d !important;
        color: #2d1b4e !important;
        font-weight: 600;
    }
    
    .animate-in {
        animation: fadeInUp 0.6s ease-out forwards;
        opacity: 0;
    }
    
    @keyframes fadeInUp {
        from { 
            opacity: 0; 
            transform: translateY(30px); 
        }
        to { 
            opacity: 1; 
            transform: translateY(0); 
        }
    }
</style>

<div class="row pb-5 justify-content-center">
    <div class="col-lg-8">
        <?= $this->include('Layout/msgStatus') ?>
    </div>
    <div class="col-lg-8 mb-3 animate-in">
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col pt-1">
                        <i class="bi bi-key-fill me-2"></i> Key Information
                    </div>
                    <div class="col">
                        <div class="text-end">
                            <a class="btn btn-sm btn-outline-light" href="<?= site_url('keys/generate') ?>" data-bs-toggle="tooltip" data-bs-placement="top" title="Generate Key"><i class="bi bi-plus-circle"></i></a>
                            <a class="btn btn-sm btn-outline-light" href="<?= site_url('keys') ?>" data-bs-toggle="tooltip" data-bs-placement="top" title="View All Keys"><i class="bi bi-list"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?= form_open('keys/edit') ?>

                <div class="row">
                    <input type="hidden" name="id_keys" value="<?= esc($key->id_keys) ?>">
                    
                    <?php if (($user->level == 1) || ($user->level == 2)) : ?>
                        <div class="col-lg-6 mb-3">
                            <label for="game" class="form-label"><i class="bi bi-controller"></i> Games</label>
                            <input type="text" name="game" id="game" class="form-control" placeholder="RandomKey" value="<?= esc($game_value) ?>">
                            <?php if (!empty($errors['game'])) : ?>
                                <small class="text-danger"><?= esc($errors['game']) ?></small>
                            <?php endif; ?>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label for="user_key" class="form-label"><i class="bi bi-key-fill"></i> User Key</label>
                            <input type="text" name="user_key" id="user_key" class="form-control" placeholder="RandomKey" value="<?= esc($user_key_value) ?>">
                            <?php if (!empty($errors['user_key'])) : ?>
                                <small class="text-danger"><?= esc($errors['user_key']) ?></small>
                            <?php endif; ?>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label for="duration" class="form-label"><i class="bi bi-clock"></i> Duration <small class="text-muted">(in hours)</small></label>
                            <input type="number" name="duration" id="duration" class="form-control" placeholder="3" value="<?= esc($duration_value) ?>">
                            <?php if (!empty($errors['duration'])) : ?>
                                <small class="text-danger"><?= esc($errors['duration']) ?></small>
                            <?php endif; ?>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label for="max_devices" class="form-label"><i class="bi bi-phone-vibrate-fill"></i> Max Devices</label>
                            <input type="number" name="max_devices" id="max_devices" class="form-control" placeholder="3" value="<?= esc($max_devices_value) ?>">
                            <?php if (!empty($errors['max_devices'])) : ?>
                                <small class="text-danger"><?= esc($errors['max_devices']) ?></small>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    
                    <div class="col-md-6 mb-3" id="col-status">
                        <label for="status" class="form-label"><i class="bi bi-shield-check"></i> Status</label>
                        <?= form_dropdown(['class' => 'form-select', 'name' => 'status', 'id' => 'status'], $sel_status, esc($status_value)) ?>
                        <?php if (!empty($errors['status'])) : ?>
                            <small class="text-danger"><?= esc($errors['status']) ?></small>
                        <?php endif; ?>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label for="registrator" class="form-label"><i class="bi bi-person-fill"></i> Registrator</label>
                        <input type="text" name="registrator" id="registrator" class="form-control" placeholder="nata" value="<?= esc($registrator_value) ?>">
                        <?php if (!empty($errors['registrator'])) : ?>
                            <small class="text-danger"><?= esc($errors['registrator']) ?></small>
                        <?php endif; ?>
                    </div>
                    
                    <div class="col-md-12 mb-3">
                        <label for="expired_date" class="form-label"><i class="bi bi-calendar-x-fill"></i> Expired <?= $expired_badge ?></label>
                        <input type="text" name="expired_date" id="expired_date" class="form-control" placeholder="<?= $time::now() ?>" value="<?= esc($expired_date_value) ?>">
                        <?php if (!empty($errors['expired_date'])) : ?>
                            <small class="text-danger"><?= esc($errors['expired_date']) ?></small>
                        <?php endif; ?>
                    </div>
                    
                    <div class="col-lg-12 mb-4">
                        <label for="devices" class="form-label"><i class="bi bi-list-ul"></i> Devices <span class="maxDev"><?= esc($key_info->total) ?>/<?= esc($key->max_devices) ?></span> <small class="text-muted">(Separately with enter)</small></label>
                        <textarea class="form-control" name="devices" id="devices" rows="<?= esc(($key_info->total > $key->max_devices) ? 3 : $key_info->total) ?>"><?= esc($devices_value) ?></textarea>
                        <?php if (!empty($errors['devices'])) : ?>
                            <small class="text-danger"><?= esc($errors['devices']) ?></small>
                        <?php endif; ?>
                    </div>
                    
                    <div class="col-lg-6">
                        <button class="btn btn-outline-info btnUpdate w-100" disabled>
                            <i class="bi bi-save me-2"></i> Update User Key
                        </button>
                    </div>
                </div>
                <?= form_close() ?>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('js') ?>
<script>
    $(document).ready(function() {
        var level = "<?= $user->level ?>";
        if (level != 1) $("#registrator, #expired_date, #devices").attr('disabled', true);
        
        $("input, select, textarea").change(function() {
            $(".btnUpdate").attr('disabled', false);
        });
        
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function (el) {
            return new bootstrap.Tooltip(el);
        });
        
        document.querySelectorAll('.animate-in').forEach(el => {
            el.style.animationPlayState = 'running';
        });
    });
    
    var total = "<?= esc($key_info->total) ?>";
    $("#max_devices").change(function() {
        $(".maxDev").html(total + '/' + $(this).val());
        $("#devices").attr('rows', Math.max($(this).val(), 3));
    });
</script>
<?= $this->endSection() ?>